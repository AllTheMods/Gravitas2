// priority 10

const convertBucketsToIngots = (event) => {
  event.add("tfc.tooltip.item_melts_into_ingots", "§7Melts into %s ingot(s) of §f%s§7 (at %s§7)")
}
