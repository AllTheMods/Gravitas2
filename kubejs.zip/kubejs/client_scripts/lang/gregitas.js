// priority 10

const addGregitasName = (event) => {
  event.add("jade.modName.gregitas", "Gravitas²")
}
