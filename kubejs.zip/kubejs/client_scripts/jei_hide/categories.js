// priority 10

let hideCats = (event) => {

   event.remove("immersiveengineering:alloy")
   event.remove("immersiveengineering:arc_furnace")
   event.remove("immersiveengineering:arc_recycling")
   event.remove("immersiveengineering:blast_furnace")
   event.remove("immersiveengineering:blast_furnace_fuel")
   event.remove("immersiveengineering:blueprint")
   event.remove("immersiveengineering:bottling_machine")
   event.remove("immersiveengineering:coke_oven")
   event.remove("immersiveengineering:crusher")
   event.remove("immersiveengineering:fermenter")
   event.remove("immersiveengineering:metal_press")
   event.remove("immersiveengineering:mixer")
   event.remove("immersiveengineering:refinery")
   event.remove("immersiveengineering:sawmill")
   event.remove("immersiveengineering:squeezer")

}
