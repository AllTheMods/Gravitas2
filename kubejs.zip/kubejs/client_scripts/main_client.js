// priority 0

ClientEvents.tick((event) => {
  observeGtQuest(event) // TODO: needs rework
})

NetworkEvents.dataReceived('customTask', event => {
  clientObserveGtTask(event) // TODO: needs rework
})

JEIEvents.hideItems(event => {
  hidePotions(event)
})

JEIEvents.removeCategories(event => {
  hideCats(event)
})
ClientEvents.lang("en_us", (event) => {
  addGregOresLang(event)
  addGregitasName(event)
  convertBucketsToIngots(event)
})

ItemEvents.tooltip(event => {
  addModNameTooltipToCreativeTab(event)
  circuitTooltips(event)
})
