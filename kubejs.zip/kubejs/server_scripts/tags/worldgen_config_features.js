// priority 10

const addConfiguredFeaturesTags = (/** @type {TagEvent.ConfiguredFeature} */ event) => {
  event.add("tfc:forest_trees", "tfc:tree/rubber_entry")
}
